package com.example.jerkcityirc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.net.wifi.WifiManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Socket
import java.net.URL
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.security.cert.X509Certificate
import kotlin.random.Random

/**
 * Foreground service that owns the IRC socket connection so the bot keeps
 * running even when MainActivity isn't in the foreground. Reports log
 * lines and status back to the UI via LocalBroadcast-style callbacks
 * (simple static listener list here to keep the sample small).
 */
class IrcService : Service() {

    companion object {
        const val CHANNEL_ID = "jerkcity_irc_service"
        const val NOTIF_ID = 1

        const val EXTRA_SERVER = "server"
        const val EXTRA_PORT = "port"
        const val EXTRA_TLS = "tls"
        const val EXTRA_ALLOW_SELF_SIGNED = "allow_self_signed"
        const val EXTRA_NICK = "nick"
        const val EXTRA_CHANNEL = "channel"
        const val EXTRA_TRIGGER = "trigger"
        const val EXTRA_AUTO_JERK_ENABLED = "auto_jerk_enabled"
        const val EXTRA_AUTO_JERK_PROBABILITY = "auto_jerk_probability"

        // Simple in-process listener so MainActivity can show live logs.
        var listener: ((String) -> Unit)? = null
        var statusListener: ((String) -> Unit)? = null

        val FALLBACK_QUOTES = listOf(
            "SPIGOT: I AM A GENIUS AND EVERYONE AROUND ME IS AN IDIOT.",
            "DEUCE: I HAVE MADE A TERRIBLE MISTAKE.",
            "PANTS: THIS IS THE WORST DAY OF MY LIFE, AND I HAVE HAD SOME BAD DAYS.",
            "RANDS: I DON'T KNOW WHAT'S GOING ON BUT I DON'T LIKE IT.",
            "T: EVERYTHING IS FINE. NOTHING IS FINE.",
            "DICK: I HAVE A PLAN AND THE PLAN IS TO HAVE NO PLAN.",
            "HANFORD: THIS SEEMED LIKE A GOOD IDEA AT THE TIME.",
            "OZONE: I REGRET EVERYTHING."
        ).filter { it.trim().split(Regex("\\s+")).size >= 4 }

        const val MIN_QUOTE_WORDS = 4

        const val QUOTE_LINES_URL =
            "https://raw.githubusercontent.com/d-flatline/JerkBot/main/jerkcity.lines"
        const val QUOTE_DELIMITER = "%%"
    }

    private var job: Job? = null
    private var socket: Socket? = null
    private var quotes: List<String> = FALLBACK_QUOTES
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Connecting..."))

        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK, "JerkcityIRC::ConnectionWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(
                WifiManager.WIFI_MODE_FULL_HIGH_PERF, "JerkcityIRC::WifiLock"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        }

        val server = intent?.getStringExtra(EXTRA_SERVER) ?: "irc.libera.chat"
        val port = intent?.getIntExtra(EXTRA_PORT, 6697) ?: 6697
        val useTls = intent?.getBooleanExtra(EXTRA_TLS, true) ?: true
        val allowSelfSigned = intent?.getBooleanExtra(EXTRA_ALLOW_SELF_SIGNED, false) ?: false
        val nick = intent?.getStringExtra(EXTRA_NICK) ?: "jerkcitybot"
        val channel = intent?.getStringExtra(EXTRA_CHANNEL) ?: "#test"
        val trigger = intent?.getStringExtra(EXTRA_TRIGGER) ?: "!jerkcity"
        val autoJerkEnabled = intent?.getBooleanExtra(EXTRA_AUTO_JERK_ENABLED, false) ?: false
        val autoJerkProbability = intent?.getIntExtra(EXTRA_AUTO_JERK_PROBABILITY, 10) ?: 10

        job?.cancel()
        job = CoroutineScope(Dispatchers.IO).launch {
            loadQuotes()
            runLoop(server, port, useTls, allowSelfSigned, nick, channel, trigger, autoJerkEnabled, autoJerkProbability)
        }

        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        try { socket?.close() } catch (_: Exception) {}
        try { wakeLock?.release() } catch (_: Exception) {}
        try { wifiLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun log(msg: String) {
        listener?.invoke(msg)
    }

    private fun setStatus(status: String) {
        statusListener?.invoke(status)
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(status))
    }

    /** Best-effort download of the community quote list, split on "%%". Falls back silently. */
    private fun loadQuotes() {
        try {
            val text = URL(QUOTE_LINES_URL).readText()
            val parsed = text.split(QUOTE_DELIMITER)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .filter { it.split(Regex("\\s+")).size >= MIN_QUOTE_WORDS }
            if (parsed.isNotEmpty()) {
                quotes = parsed
                log("Loaded ${parsed.size} quotes online.")
            } else {
                log("Online quote list empty, using built-in fallback.")
            }
        } catch (e: Exception) {
            log("Could not fetch online quotes (${e.message}); using built-in fallback list.")
        }
    }

    /** TrustManager that accepts any certificate. Only used when the user opts in. */
    private fun buildTrustAllSslSocketFactory(): SSLSocketFactory {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf<TrustManager>(trustAll), java.security.SecureRandom())
        return ctx.socketFactory
    }

    private suspend fun runLoop(
        server: String,
        port: Int,
        useTls: Boolean,
        allowSelfSigned: Boolean,
        nick: String,
        channel: String,
        trigger: String,
        autoJerkEnabled: Boolean,
        autoJerkProbability: Int
    ) {
        while (job?.isActive == true) {
            try {
                setStatus("Connecting to $server:$port...")
                val plain = Socket(server, port)
                plain.keepAlive = true
                val sock: Socket = if (useTls) {
                    val factory = if (allowSelfSigned) buildTrustAllSslSocketFactory()
                                  else SSLSocketFactory.getDefault() as SSLSocketFactory
                    factory.createSocket(plain, server, port, true)
                } else plain
                sock.keepAlive = true
                socket = sock

                val out: OutputStream = sock.getOutputStream()
                val reader = BufferedReader(InputStreamReader(sock.getInputStream()))

                fun send(line: String) {
                    out.write((line + "\r\n").toByteArray(Charsets.UTF_8))
                    out.flush()
                }

                send("NICK $nick")
                send("USER $nick 0 * :$nick")

                setStatus("Connected, registering...")
                var joined = false
                val privmsgRegex = Regex("^:([^!]+)!\\S+ PRIVMSG (\\S+) :(.*)$")

                // Some mobile networks/NATs silently drop TCP connections that
                // sit idle too long, even with TCP keepalive enabled (its
                // default interval is often ~2 hours, far too slow to help
                // here). Proactively ping the server every 60s so there's
                // always outbound traffic keeping the connection alive.
                val keepaliveJob = CoroutineScope(Dispatchers.IO).launch {
                    while (isActive) {
                        delay(60000)
                        try {
                            send("PING :keepalive")
                        } catch (_: Exception) {
                            // Let the main read loop below detect and handle the failure.
                        }
                    }
                }

                try {
                    while (job?.isActive == true) {
                        val line = reader.readLine() ?: throw java.io.IOException("Server closed connection")
                        log(line)

                        if (line.startsWith("PING")) {
                            send("PONG" + line.substring(4))
                            continue
                        }

                        if (!joined && " 001 " in line) {
                            send("JOIN $channel")
                            joined = true
                            setStatus("Joined $channel")
                        }

                        val match = privmsgRegex.find(line) ?: continue
                        val (fromNick, target, text) = match.destructured
                        val trimmedText = text.trim()

                        if (fromNick.equals(nick, ignoreCase = true)) continue

                        if (trimmedText.startsWith(trigger, ignoreCase = true)) {
                            val replyTarget = if (target.startsWith("#")) target else fromNick
                            if (fromNick.equals("bananas", ignoreCase = true)) {
                                send("PRIVMSG $replyTarget :STFU bananas you cretin")
                            } else {
                                val suffix = trimmedText.substring(trigger.length).trim()
                                val pick: String? = if (suffix.isNotEmpty()) {
                                    val matches = quotes.filter { it.contains(suffix, ignoreCase = true) }
                                    if (matches.isNotEmpty()) matches[Random.nextInt(matches.size)] else null
                                } else {
                                    quotes[Random.nextInt(quotes.size)]
                                }
                                if (pick != null) {
                                    val trimmed = if (pick.length > 400) pick.substring(0, 400) + "..." else pick
                                    send("PRIVMSG $replyTarget :$trimmed")
                                } else {
                                    send("PRIVMSG $replyTarget :No quote found containing \"$suffix\".")
                                }
                            }
                        } else if (autoJerkEnabled && target.startsWith("#")) {
                            // "Auto Jerk": on ordinary (non-command) channel chatter,
                            // roll the configured probability; on success, pick a
                            // random word over 4 letters from that message and, if
                            // a quote containing it exists, post it unprompted.
                            if (Random.nextInt(100) < autoJerkProbability) {
                                val candidateWords = trimmedText
                                    .split(Regex("[^\\p{L}']+"))
                                    .filter { it.length > 4 }
                                if (candidateWords.isNotEmpty()) {
                                    val word = candidateWords[Random.nextInt(candidateWords.size)]
                                    val matches = quotes.filter { it.contains(word, ignoreCase = true) }
                                    if (matches.isNotEmpty()) {
                                        val pick = matches[Random.nextInt(matches.size)]
                                        val trimmed = if (pick.length > 400) pick.substring(0, 400) + "..." else pick
                                        send("PRIVMSG $target :$trimmed")
                                        log("[auto-jerk] triggered on word \"$word\"")
                                    }
                                }
                            }
                        }
                    }
                } finally {
                    keepaliveJob.cancel()
                }
            } catch (e: Exception) {
                log("Connection error: ${e.message}. Reconnecting in 15s...")
                setStatus("Disconnected, retrying...")
                delay(15000)
            }
        }
    }

    private fun buildNotification(status: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID, "Jerkcity IRC Bot", NotificationManager.IMPORTANCE_LOW
                    )
                )
            }
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jerkcity IRC Bot")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setOngoing(true)
            .build()
    }
}
