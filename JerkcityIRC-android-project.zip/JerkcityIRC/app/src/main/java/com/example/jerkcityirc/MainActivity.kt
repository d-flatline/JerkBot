package com.example.jerkcityirc

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.example.jerkcityirc.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val logLines = StringBuilder()
    private val prefs by lazy { getSharedPreferences("jerkcity_irc_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSavedSettings()
        setupTabs()

        IrcService.listener = { line ->
            runOnUiThread {
                logLines.append(line).append("\n")
                // Keep the log from growing without bound.
                if (logLines.length > 8000) {
                    logLines.delete(0, logLines.length - 8000)
                }
                binding.textLog.text = logLines.toString()
            }
        }
        IrcService.statusListener = { status ->
            runOnUiThread {
                binding.textStatus.text = "Status: $status"
                binding.textStatus.setTextColor(ResourcesCompat.getColor(resources, statusColorFor(status), theme))
            }
        }

        binding.buttonStart.setOnClickListener {
            saveSettings()
            requestNotificationPermissionIfNeeded()
            requestBatteryOptimizationExemption()
            startBot()
        }
        binding.buttonStop.setOnClickListener {
            stopService(Intent(this, IrcService::class.java))
            binding.textStatus.text = "Status: stopped"
            binding.textStatus.setTextColor(ResourcesCompat.getColor(resources, R.color.status_stopped, theme))
        }

        binding.sliderAutoJerk.addOnChangeListener { _, value, _ ->
            binding.textAutoJerkValue.text = "${value.toInt()}%"
        }
    }

    private fun setupTabs() {
        val pages = listOf(binding.pageConnection, binding.pageBot, binding.pageAutoJerk, binding.pageLog)
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                pages.forEachIndexed { index, page ->
                    page.visibility = if (index == tab.position) View.VISIBLE else View.GONE
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun statusColorFor(status: String): Int {
        val s = status.lowercase()
        return when {
            "error" in s || "disconnect" in s -> R.color.status_error
            "connecting" in s || "retrying" in s || "starting" in s || "registering" in s -> R.color.status_connecting
            "joined" in s || "connected" in s -> R.color.status_connected
            else -> R.color.status_stopped
        }
    }

    private fun loadSavedSettings() {
        binding.editServer.setText(prefs.getString("server", "irc.libera.chat"))
        binding.editPort.setText(prefs.getString("port", "6697"))
        binding.checkTls.isChecked = prefs.getBoolean("tls", true)
        binding.checkAllowSelfSigned.isChecked = prefs.getBoolean("allow_self_signed", false)
        binding.editNick.setText(prefs.getString("nick", "jerkcitybot"))
        binding.editChannel.setText(prefs.getString("channel", "#yourchannel"))
        binding.editTrigger.setText(prefs.getString("trigger", "!jerkcity"))
        binding.checkAutoJerk.isChecked = prefs.getBoolean("auto_jerk_enabled", false)
        val savedProbability = prefs.getInt("auto_jerk_probability", 10)
        binding.sliderAutoJerk.value = savedProbability.toFloat()
        binding.textAutoJerkValue.text = "$savedProbability%"
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("server", binding.editServer.text.toString().trim())
            .putString("port", binding.editPort.text.toString().trim())
            .putBoolean("tls", binding.checkTls.isChecked)
            .putBoolean("allow_self_signed", binding.checkAllowSelfSigned.isChecked)
            .putString("nick", binding.editNick.text.toString().trim())
            .putString("channel", binding.editChannel.text.toString().trim())
            .putString("trigger", binding.editTrigger.text.toString().trim())
            .putBoolean("auto_jerk_enabled", binding.checkAutoJerk.isChecked)
            .putInt("auto_jerk_probability", binding.sliderAutoJerk.value.toInt())
            .apply()
    }

    private fun startBot() {
        val server = binding.editServer.text.toString().trim()
        val port = binding.editPort.text.toString().trim().toIntOrNull() ?: 6697
        val tls = binding.checkTls.isChecked
        val allowSelfSigned = binding.checkAllowSelfSigned.isChecked
        val nick = binding.editNick.text.toString().trim()
        val channel = binding.editChannel.text.toString().trim()
        val trigger = binding.editTrigger.text.toString().trim()

        val intent = Intent(this, IrcService::class.java).apply {
            putExtra(IrcService.EXTRA_SERVER, server)
            putExtra(IrcService.EXTRA_PORT, port)
            putExtra(IrcService.EXTRA_TLS, tls)
            putExtra(IrcService.EXTRA_ALLOW_SELF_SIGNED, allowSelfSigned)
            putExtra(IrcService.EXTRA_NICK, nick)
            putExtra(IrcService.EXTRA_CHANNEL, channel)
            putExtra(IrcService.EXTRA_TRIGGER, trigger)
            putExtra(IrcService.EXTRA_AUTO_JERK_ENABLED, binding.checkAutoJerk.isChecked)
            putExtra(IrcService.EXTRA_AUTO_JERK_PROBABILITY, binding.sliderAutoJerk.value.toInt())
        }
        ContextCompat.startForegroundService(this, intent)
        binding.textStatus.text = "Status: starting..."
    }

    private fun requestBatteryOptimizationExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
                // Some OEM ROMs block this intent; user can still exempt manually
                // via Settings > Apps > Jerkcity IRC Bot > Battery.
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001
                )
            }
        }
    }
}
