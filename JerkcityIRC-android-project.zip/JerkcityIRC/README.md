# Jerkcity IRC Bot (Android)

A small Android app with a GUI front-end for the IRC quote bot. Enter
server details, tap Start, and it runs as a foreground service (with a
persistent notification) so it keeps the IRC connection alive in the
background. Tap Stop to disconnect.

## Features
- **Auto Jerk:** an optional mode (its own tab) where the bot doesn't
  wait for the trigger command. On every ordinary channel message, it
  rolls a configurable probability (0–100%, via a slider); on a hit,
  it picks a random word over 4 letters from that message and, if a
  quote containing that word exists, posts it unprompted. Off by
  default.
- **Tabbed interface:** settings are split into four tabs —
  Connection, Bot, Auto Jerk, and Log — so each section stays focused
  and uncluttered. Start/Stop and the status line are always visible
  underneath, regardless of which tab is open.
- Fields for server, port, TLS on/off, "allow self-signed certificate"
  toggle, nickname, channel, and trigger command — all with clear
  labels via Material Design floating-label fields and switches
- **Word-targeted quotes:** add a word after your trigger command
  (e.g. `!jerkcity pizza`) to get a random quote containing that word,
  instead of a fully random one. If nothing matches, the bot says so.
  Works in-channel or as a direct message to the bot.
- Special-cased response for the nickname `bananas`
- **Settings are saved automatically** (via SharedPreferences) whenever
  you tap Start, and reloaded the next time you open the app
- A sleeker, flat two-color app icon (dark background, yellow speech
  bubble) — an original design, not reproducing any Jerkcity artwork
  or characters, which are the artist's copyrighted work
- Live scrolling log of raw IRC traffic (its own tab), with a
  color-coded status line (grey = stopped, amber = connecting,
  green = connected/joined, red = error)
- Runs as a foreground service so Android doesn't kill the connection
  when you leave the app
- Downloads the community quote list from d-flatline/JerkBot
  (`jerkcity.lines`, entries split on `%%`) at connect time, filtering
  out anything under 4 words, and falling back to a small built-in
  offline list if the download fails

## How to build the APK

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Open this project folder (`JerkcityIRC/`) in Android Studio —
   "Open" and point it at the folder containing this README.
3. Let Gradle sync (first sync will download dependencies; needs
   internet).
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Android Studio will show a notification with a "locate" link to
   the generated `app-debug.apk` (under `app/build/outputs/apk/debug/`).
6. Copy that APK to your phone and install it (you'll need to allow
   "install from unknown sources" for the app you use to open it).

Alternatively, from a terminal with the Android SDK installed:
```
cd JerkcityIRC
./gradlew assembleDebug
```
(You'll need to generate the Gradle wrapper first with
`gradle wrapper` if `gradlew` isn't present, or just use Android
Studio's built-in Gradle — that's the simpler path.)

## Notes
- **Idle-connection drops ("read error" quits):** many mobile networks
  and NATs silently kill TCP connections that sit quiet too long, even
  with TCP keepalive on (its default probe interval is often ~2 hours,
  far too slow to matter here). The service now sends a `PING` to the
  server every 60 seconds when otherwise idle to keep the connection
  active, enables TCP-level keepalive as a second layer, and holds a
  partial wake lock while running so the CPU sleeping doesn't stall
  the socket.
- **"Software caused connection abort" / continued drops:** this
  specific error means Android itself killed the socket, usually
  because Doze mode / App Standby (or an OEM battery manager like
  Samsung's or Xiaomi's) cut network access out from under the
  foreground service. Tapping Start now also prompts you to exempt
  the app from battery optimization — accept that prompt. The service
  also holds a Wi-Fi lock (`WIFI_MODE_FULL_HIGH_PERF`) so the radio
  itself doesn't sleep. If your phone still kills it, check
  Settings → Apps → Jerkcity IRC Bot → Battery and set it to
  "Unrestricted" manually (exact wording/location varies by OEM).
- The "allow self-signed certificates" option disables TLS certificate
  verification entirely (no hostname check, no CA validation). Only
  enable it against a server you control/trust — it removes protection
  against man-in-the-middle attacks.
- Jerkcity is NSFW/crude humor content — only point this at channels
  where that's welcome.
- This is unsigned debug output; for a "real" release build (Play
  Store, distributing outside your own devices) you'd need to
  generate a signing key and do `assembleRelease`, which Android
  Studio's "Generate Signed Bundle / APK" wizard walks you through.
